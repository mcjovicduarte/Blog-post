<?php
require __DIR__ . '/components/projects.php';
