<?php

function getDatabaseConfig(): array
{
    return [
        'host' => 'localhost',
        'dbname' => 'portfolio_blog',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8mb4',
    ];
}

function connectDatabase(): PDO
{
    $config = getDatabaseConfig();

    try {
        $dsn = 'mysql:host=' . $config['host'] . ';charset=' . $config['charset'];
        $pdo = new PDO($dsn, $config['username'], $config['password'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);

        $pdo->exec('CREATE DATABASE IF NOT EXISTS `' . $config['dbname'] . '`');
    } catch (Throwable $e) {
        throw new RuntimeException('Unable to connect to MySQL server: ' . $e->getMessage());
    }

    $dsn = 'mysql:host=' . $config['host'] . ';dbname=' . $config['dbname'] . ';charset=' . $config['charset'];
    $pdo = new PDO($dsn, $config['username'], $config['password'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    ensureDatabaseTables($pdo);

    return $pdo;
}

function ensureDatabaseTables(PDO $pdo): void
{
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS profiles (
            id INT AUTO_INCREMENT PRIMARY KEY,
            full_name VARCHAR(150) NOT NULL,
            title VARCHAR(150) NOT NULL,
            photo VARCHAR(255) NOT NULL,
            about_text TEXT NOT NULL,
            skills TEXT NOT NULL,
            email VARCHAR(150) NOT NULL,
            phone VARCHAR(50) NOT NULL,
            location VARCHAR(150) NOT NULL,
            facebook VARCHAR(255) DEFAULT NULL,
            linkedin VARCHAR(255) DEFAULT NULL,
            github VARCHAR(255) DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );

    $columns = $pdo->query('SHOW COLUMNS FROM profiles')->fetchAll(PDO::FETCH_COLUMN);

    if (! in_array('facebook', $columns, true)) {
        $pdo->exec('ALTER TABLE profiles ADD COLUMN facebook VARCHAR(255) DEFAULT NULL AFTER location');
    }

    if (! in_array('linkedin', $columns, true)) {
        $pdo->exec('ALTER TABLE profiles ADD COLUMN linkedin VARCHAR(255) DEFAULT NULL AFTER facebook');
    }

    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS projects (
            id INT AUTO_INCREMENT PRIMARY KEY,
            profile_id INT NOT NULL,
            title VARCHAR(150) NOT NULL,
            image VARCHAR(255) NOT NULL,
            description TEXT NOT NULL,
            technologies VARCHAR(255) NOT NULL,
            features TEXT NOT NULL,
            project_url VARCHAR(255) DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (profile_id) REFERENCES profiles(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );

    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS blog_posts (
            id INT AUTO_INCREMENT PRIMARY KEY,
            profile_id INT NOT NULL,
            title VARCHAR(200) NOT NULL,
            featured_image VARCHAR(255) NOT NULL,
            excerpt TEXT NOT NULL,
            content LONGTEXT NOT NULL,
            published_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (profile_id) REFERENCES profiles(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );

    syncProfileSeedData($pdo);
    seedSampleData($pdo);
    ensurePrelimPokemonProject($pdo);
    ensureWs101ExamProject($pdo);
    ensureItProfEl1Project($pdo);
    ensureHappyToesProject($pdo);
}

function syncProfileSeedData(PDO $pdo): void
{
    $profiles = fallbackProfiles();

    foreach ($profiles as $profile) {
        $stmt = $pdo->prepare(
            'INSERT INTO profiles (id, full_name, title, photo, about_text, skills, email, phone, location, facebook, linkedin, github)
             VALUES (:id, :full_name, :title, :photo, :about_text, :skills, :email, :phone, :location, :facebook, :linkedin, :github)
             ON DUPLICATE KEY UPDATE
                full_name = VALUES(full_name),
                title = VALUES(title),
                photo = VALUES(photo),
                about_text = VALUES(about_text),
                skills = VALUES(skills),
                email = VALUES(email),
                phone = VALUES(phone),
                location = VALUES(location),
                facebook = VALUES(facebook),
                linkedin = VALUES(linkedin),
                github = VALUES(github)'
        );

        $stmt->execute([
            'id' => (int) $profile['id'],
            'full_name' => $profile['full_name'],
            'title' => $profile['title'],
            'photo' => $profile['photo'],
            'about_text' => $profile['about_text'],
            'skills' => $profile['skills'],
            'email' => $profile['email'],
            'phone' => $profile['phone'],
            'location' => $profile['location'],
            'facebook' => $profile['facebook'] ?? null,
            'linkedin' => $profile['linkedin'] ?? 'https://www.linkedin.com',
            'github' => $profile['github'] ?? 'https://github.com',
        ]);
    }
}

function seedSampleData(PDO $pdo): void
{
    $profileCount = (int) $pdo->query('SELECT COUNT(*) FROM profiles')->fetchColumn();

    if ($profileCount > 0) {
        return;
    }

    $profileData = [
        [
            'full_name' => 'Mc Jovic L. Duarte',
            'title' => 'Student',
            'photo' => 'Img/mcproff.jpeg',
            'about_text' => 'I’m Mc Jovic L. Duarte, an Information Technology student who enjoys learning about web development and creating simple, useful applications. I’m always looking for opportunities to improve my skills and gain new experiences in technology.',
            'skills' => 'HTML, Nextjs, JavaScript, React, CSS, Figma',
            'email' => 'mcjovicduarte.202300566@gmail.com',
            'phone' => '09692094727',
            'location' => 'Abuno,Iligan City, Philippines',
            'facebook' => 'https://www.facebook.com/mcjovic.lemosneroduarte',
            'github' => 'https://github.com/',
        ],
        [
            'full_name' => 'Jhon Lloyd J. Soco',
            'title' => 'Student',
            'photo' => 'Img/jhon.jpeg',
            'about_text' => 'I’m Jhon Lloyd J. Soco, an Information Technology student who is interested in web development and technology. I enjoy learning new skills, working on projects, and improving my knowledge through hands-on experience.',
            'skills' => 'HTML, CSS, JavaScript, React, Figma',
            'email' => 'jhonlloydsoco.202300134@gmail.com',
            'phone' => '09456095830',
            'location' => 'Tipanoy,Iligan City, Philippines',
            'facebook' => 'https://www.facebook.com/Kyoojl',
            'github' => 'https://github.com/',
        ],
    ];

    foreach ($profileData as $profile) {
        $stmt = $pdo->prepare(
            'INSERT INTO profiles (full_name, title, photo, about_text, skills, email, phone, location, facebook, github)
             VALUES (:full_name, :title, :photo, :about_text, :skills, :email, :phone, :location, :facebook, :github)'
        );
        $stmt->execute($profile);
    }

    $profiles = $pdo->query('SELECT * FROM profiles ORDER BY id ASC')->fetchAll();

    $projectData = [
        [
            'profile_id' => $profiles[0]['id'],
            'title' => 'CampusConnect Portal',
            'image' => 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=1200&q=80',
            'description' => 'A student collaboration platform designed to organize schedules, projects, and class updates in one place.',
            'technologies' => 'PHP, MySQL, Bootstrap, JavaScript',
            'features' => 'Student dashboard, calendar, assignment tracking, direct messaging',
            'project_url' => 'https://example.com/project-campusconnect',
        ],
        [
            'profile_id' => $profiles[0]['id'],
            'title' => 'Smart Inventory App',
            'image' => 'https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=1200&q=80',
            'description' => 'An inventory management dashboard to help teams monitor product stock, expenses, and supply orders quickly.',
            'technologies' => 'PHP, MySQL, Chart.js, AdminLTE',
            'features' => 'Inventory analytics, sales tracking, stock alerts, supplier records',
            'project_url' => 'https://example.com/project-inventory',
        ],
        [
            'profile_id' => $profiles[0]['id'],
            'title' => 'EventFlow Planner',
            'image' => 'https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=1200&q=80',
            'description' => 'A planning application for scheduling events, managing vendors, and tracking attendee registration.',
            'technologies' => 'HTML, JavaScript, CSS',
            'features' => 'Event timeline, RSVP dashboard, budget overview, notification center',
            'project_url' => 'https://example.com/project-eventflow',
        ],
        [
            'profile_id' => $profiles[1]['id'],
            'title' => 'FitTrack Experience',
            'image' => 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&w=1200&q=80',
            'description' => 'A wellness dashboard that encourages users to track workouts, goals, and progress with a modern interface.',
            'technologies' => 'HTML, CSS, JavaScript, PHP',
            'features' => 'Goal tracking, progress charts, habit streaks, responsive dashboard',
            'project_url' => 'https://example.com/project-fittrack',
        ],
        [
            'profile_id' => $profiles[1]['id'],
            'title' => 'Travel Planner UI',
            'image' => 'https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=1200&q=80',
            'description' => 'A destination planning interface built to help travelers compare itineraries and book experiences.',
            'technologies' => 'Figma, JavaScript, Sass, PHP',
            'features' => 'Trip booking flow, destination cards, itinerary filtering, mobile-friendly design',
            'project_url' => 'https://prelim-exam-pokemon.vercel.app/',
        ],
        [
            'profile_id' => $profiles[1]['id'],
            'title' => 'Brand Launch Kit',
            'image' => 'https://images.unsplash.com/photo-1522204523234-8729aa6e3b6f?auto=format&fit=crop&w=1200&q=80',
            'description' => 'A promotional landing page kit for new startups that need a polished, conversion-driven digital presence.',
            'technologies' => 'HTML, CSS, JavaScript, ',
            'features' => 'Modern landing page, testimonials, pricing cards, CTA sections',
            'project_url' => 'https://example.com/project-brand-launch',
        ],
    ];

    foreach ($projectData as $project) {
        $stmt = $pdo->prepare(
            'INSERT INTO projects (profile_id, title, image, description, technologies, features, project_url)
             VALUES (:profile_id, :title, :image, :description, :technologies, :features, :project_url)'
        );
        $stmt->execute($project);
    }

    $blogData = [
        [
            'profile_id' => $profiles[0]['id'],
            'title' => 'How I Build Better User Experiences',
            'featured_image' => 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=1200&q=80',
            'excerpt' => 'A practical look at designing interfaces that are simple, fast, and genuinely helpful for users.',
            'content' => 'Good user experience begins with listening carefully to the actual problem. In practice, this means reducing clutter, improving flow, and ensuring that every interaction has a clear purpose. When I build products, I try to simplify the experience before I add any fancy features. That keeps the interface intuitive, the code easier to maintain, and the final product more trustworthy for users. Whether I am creating a dashboard or a small business website, I always begin by mapping the journey and removing confusion from each step.',
        ],
        [
            'profile_id' => $profiles[0]['id'],
            'title' => 'Choosing the Right Tech Stack for Student Projects',
            'featured_image' => 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1200&q=80',
            'excerpt' => 'Selecting the right tools can make a project easier to build, easier to explain, and easier to maintain.',
            'content' => 'For student and portfolio projects, the technology stack should match the learning goal and the project outcome. PHP and MySQL are a great fit for building robust content-driven applications, while JavaScript adds a smoother user experience on the front end. The key is not to chase trends but to choose the simplest stack that solves the problem clearly. This creates a cleaner codebase, faster development, and better understanding of how each layer works.',
        ],
        [
            'profile_id' => $profiles[1]['id'],
            'title' => 'The Value of Responsive Design in Portfolio Work',
            'featured_image' => 'https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&w=1200&q=80',
            'excerpt' => 'Responsive design matters because people interact with digital content on different devices and in different contexts.',
            'content' => 'A portfolio website is often the first impression a client or recruiter gets of a designer or developer. That means it must feel polished on mobile, tablet, and desktop. Responsive design is not only about shrinking layouts, but also about maintaining hierarchy, readability, and clarity throughout the experience. Great design creates confidence because it makes the work feel deliberate, credible, and easy to explore.',
        ],
    ];

    foreach ($blogData as $post) {
        $stmt = $pdo->prepare(
            'INSERT INTO blog_posts (profile_id, title, featured_image, excerpt, content, published_at)
             VALUES (:profile_id, :title, :featured_image, :excerpt, :content, NOW())'
        );
        $stmt->execute($post);
    }
}

function ensurePrelimPokemonProject(PDO $pdo): void
{
    $projectUrl = 'https://prelim-exam-pokemon.vercel.app/';
    $oldUrls = [
        'https://prelim-exam-pokemon-1o0nvntde-mc-jovic-duartes-projects.vercel.app',
        'https://prelim-exam-pokemon-1o0nvntde-mc-jovic-duartes-projects.vercel.app/',
    ];

    // Migrate any old Vercel URL to the new one so View Project goes to your own project.
    $migrate = $pdo->prepare('UPDATE projects SET project_url = :new_url WHERE project_url = :old_url');
    foreach ($oldUrls as $oldUrl) {
        $migrate->execute(['new_url' => $projectUrl, 'old_url' => $oldUrl]);
    }

    $stmt = $pdo->prepare('SELECT COUNT(*) FROM projects WHERE project_url = :project_url');
    $stmt->execute(['project_url' => $projectUrl]);

    if ((int) $stmt->fetchColumn() > 0) {
        return;
    }

    $stmt = $pdo->prepare(
        'INSERT INTO projects (profile_id, title, image, description, technologies, features, project_url)
         VALUES (:profile_id, :title, :image, :description, :technologies, :features, :project_url)'
    );
    $stmt->execute([
        'profile_id' => 1,
        'title' => 'Prelim Exam - Pokemon App',
        'image' => 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/25.png',
        'description' => 'Prelim exam project by Mc Jovic Duarte - a Pokemon explorer app deployed on Vercel.',
        'technologies' => 'Next.js, JavaScript, CSS, Vercel, PokeAPI',
        'features' => 'Pokemon listing, search, details view, responsive UI',
        'project_url' => $projectUrl,
    ]);
}

function ensureWs101ExamProject(PDO $pdo): void
{
    $projectUrl = 'https://ws101-exam.vercel.app/';

    $stmt = $pdo->prepare('SELECT COUNT(*) FROM projects WHERE project_url IN (:url1, :url2)');
    $stmt->execute([
        'url1' => $projectUrl,
        'url2' => 'https://ws101-exam.vercel.app',
    ]);

    if ((int) $stmt->fetchColumn() > 0) {
        return;
    }

    $stmt = $pdo->prepare(
        'INSERT INTO projects (profile_id, title, image, description, technologies, features, project_url)
         VALUES (:profile_id, :title, :image, :description, :technologies, :features, :project_url)'
    );
    $stmt->execute([
        'profile_id' => 2,
        'title' => 'WS101 Exam App',
        'image' => 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&w=1200&q=80',
        'description' => 'WS101 exam project by Jhon Lloyd Soco - a web application deployed on Vercel.',
        'technologies' => 'HTML, CSS, JavaScript, Vercel',
        'features' => 'Responsive UI, exam requirements, deployed build',
        'project_url' => $projectUrl,
    ]);
}

function ensureItProfEl1Project(PDO $pdo): void
{
    $projectUrl = 'https://it-prof-el-1.vercel.app/';

    $stmt = $pdo->prepare('SELECT COUNT(*) FROM projects WHERE project_url IN (:url1, :url2)');
    $stmt->execute([
        'url1' => $projectUrl,
        'url2' => 'https://it-prof-el-1.vercel.app',
    ]);

    if ((int) $stmt->fetchColumn() > 0) {
        return;
    }

    $stmt = $pdo->prepare(
        'INSERT INTO projects (profile_id, title, image, description, technologies, features, project_url)
         VALUES (:profile_id, :title, :image, :description, :technologies, :features, :project_url)'
    );
    $stmt->execute([
        'profile_id' => 2,
        'title' => 'IT Prof EL1 App',
        'image' => 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80',
        'description' => 'IT Professional Elective 1 project by Jhon Lloyd Soco - a web application deployed on Vercel.',
        'technologies' => 'HTML, CSS, JavaScript, Vercel',
        'features' => 'Responsive UI, course requirements, deployed build',
        'project_url' => $projectUrl,
    ]);
}

function ensureHappyToesProject(PDO $pdo): void
{
    $projectUrl = 'https://happytoes.vercel.app/';

    $stmt = $pdo->prepare('SELECT COUNT(*) FROM projects WHERE project_url IN (:url1, :url2)');
    $stmt->execute([
        'url1' => $projectUrl,
        'url2' => 'https://happytoes.vercel.app',
    ]);

    if ((int) $stmt->fetchColumn() > 0) {
        return;
    }

    $stmt = $pdo->prepare(
        'INSERT INTO projects (profile_id, title, image, description, technologies, features, project_url)
         VALUES (:profile_id, :title, :image, :description, :technologies, :features, :project_url)'
    );
    $stmt->execute([
        'profile_id' => 1,
        'title' => 'Happy Toes App',
        'image' => 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=1200&q=80',
        'description' => 'Happy Toes project by Mc Jovic Duarte - a web application deployed on Vercel.',
        'technologies' => 'HTML, CSS, JavaScript, Vercel',
        'features' => 'Responsive UI, product showcase, deployed build',
        'project_url' => $projectUrl,
    ]);
}

function fallbackProfiles(): array
{
    return [
        [
            'id' => 1,
            'full_name' => 'Mc Jovic L. Duarte',
            'title' => 'Student',
            'photo' => 'Img/mcproff.jpeg',
            'about_text' => 'I’m Mc Jovic L. Duarte, an Information Technology student who enjoys learning about web development and creating simple, useful applications. I’m always looking for opportunities to improve my skills and gain new experiences in technology.',
            'skills' => 'HTML, Nextjs, JavaScript, React, CSS, Figma',
            'email' => 'mcjovicduarte.202300566@gmail.com',
            'phone' => '09692094727',
            'location' => 'Abuno,Iligan City, Philippines',
            'facebook' => 'https://www.facebook.com/mcjovic.lemosneroduarte',
            'github' => 'https://github.com/',
        ],
        [
            'id' => 2,
            'full_name' => 'Jhon Lloyd J. Soco',
            'title' => 'Student',
            'photo' => 'Img/jhon.jpeg',
            'about_text' => 'I’m Jhon Lloyd J. Soco, an Information Technology student who is interested in web development and technology. I enjoy learning new skills, working on projects, and improving my knowledge through hands-on experience.',
            'skills' => 'HTML, CSS, JavaScript, React, Figma',
            'email' => 'jhonlloydsoco.202300134@gmail.com',
            'phone' => '09456095830',
            'location' => 'Tipanoy,Iligan City, Philippines',
            'facebook' => 'https://www.facebook.com/Kyoojl',
            'github' => 'https://github.com/',
        ],
    ];
}

function getProfiles(PDO $pdo, int $limit = 0): array
{
    $query = 'SELECT * FROM profiles ORDER BY id ASC';

    if ($limit > 0) {
        $query .= ' LIMIT ' . $limit;
    }

    $stmt = $pdo->query($query);

    return $stmt->fetchAll();
}

function getProfileById(PDO $pdo, int $id): ?array
{
    $stmt = $pdo->prepare('SELECT * FROM profiles WHERE id = :id LIMIT 1');
    $stmt->execute(['id' => $id]);

    $profile = $stmt->fetch();

    return $profile ?: null;
}

function getProjects(PDO $pdo, int $limit = 0): array
{
    $query = 'SELECT p.*, pr.full_name AS author_name FROM projects p JOIN profiles pr ON pr.id = p.profile_id ORDER BY p.id DESC';

    if ($limit > 0) {
        $query .= ' LIMIT ' . $limit;
    }

    $stmt = $pdo->query($query);

    return $stmt->fetchAll();
}

function getProjectsByProfileId(PDO $pdo, int $profileId): array
{
    $stmt = $pdo->prepare('SELECT * FROM projects WHERE profile_id = :profile_id ORDER BY id ASC');
    $stmt->execute(['profile_id' => $profileId]);

    return $stmt->fetchAll();
}

function getBlogPosts(PDO $pdo, int $limit = 0): array
{
    $query = 'SELECT b.*, p.full_name AS author_name FROM blog_posts b JOIN profiles p ON p.id = b.profile_id ORDER BY b.published_at DESC';

    if ($limit > 0) {
        $query .= ' LIMIT ' . $limit;
    }

    $stmt = $pdo->query($query);

    return $stmt->fetchAll();
}

function getBlogPostById(PDO $pdo, int $id): ?array
{
    $stmt = $pdo->prepare('SELECT b.*, p.full_name AS author_name FROM blog_posts b JOIN profiles p ON p.id = b.profile_id WHERE b.id = :id LIMIT 1');
    $stmt->execute(['id' => $id]);

    $post = $stmt->fetch();

    return $post ?: null;
}
