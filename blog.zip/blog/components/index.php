<?php
require __DIR__ . '/database.php';

try {
    $pdo = connectDatabase();
    $profiles = getProfiles($pdo, 2);
    $projects = getProjects($pdo);
} catch (Throwable $e) {
    $profiles = fallbackProfiles();
    $projects = [
        [
            'title' => 'Prelim Exam - Pokemon App',
            'image' => 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/25.png',
            'description' => 'Prelim exam project by Mc Jovic Duarte - a Pokemon explorer app deployed on Vercel.',
            'technologies' => 'Next.js, JavaScript, CSS, Vercel, PokeAPI',
            'project_url' => 'https://prelim-exam-pokemon.vercel.app/',
            'author_name' => 'Mc Jovic L. Duarte',
        ],
        [
            'title' => 'Happy Toes App',
            'image' => 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=1200&q=80',
            'description' => 'Happy Toes project by Mc Jovic Duarte - a web application deployed on Vercel.',
            'technologies' => 'HTML, CSS, JavaScript, Vercel',
            'project_url' => 'https://happytoes.vercel.app/',
            'author_name' => 'Mc Jovic L. Duarte',
        ],
        [
            'title' => 'WS101 Exam App',
            'image' => 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&w=1200&q=80',
            'description' => 'WS101 exam project by Jhon Lloyd Soco - a web application deployed on Vercel.',
            'technologies' => 'HTML, CSS, JavaScript, Vercel',
            'project_url' => 'https://ws101-exam.vercel.app/',
            'author_name' => 'Jhon Lloyd J. Soco',
        ],
        [
            'title' => 'IT Prof EL1 App',
            'image' => 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80',
            'description' => 'IT Professional Elective 1 project by Jhon Lloyd Soco - a web application deployed on Vercel.',
            'technologies' => 'HTML, CSS, JavaScript, Vercel',
            'project_url' => 'https://it-prof-el-1.vercel.app/',
            'author_name' => 'Jhon Lloyd J. Soco',
        ],
    ];
}

$pageTitle = 'Home | Blog Post';
include __DIR__ . '/../partials/header.php';
?>

<section class="hero">
    <div class="container hero-grid">
        <div>
            <span class="eyebrow">Portfolio & Blog</span>
            <h1>Welcome to our blog, where we share ideas, stories, and insights through simple and meaningful posts.</h1>
            <p>The project aims to demonstrate our understanding of web development, database management, CRUD operations, and the CodeIgniter 4 framework. It is designed to provide a simple platform where users can share information and ideas through blog posts.</p>
        </div>

        <div class="hero-panel">
            <div class="hero-profile">
                <div class="avatar">
                    <img src="<?php echo htmlspecialchars($profiles[0]['photo']); ?>" alt="<?php echo htmlspecialchars($profiles[0]['full_name']); ?>" onerror="this.onerror=null;this.src='https://ui-avatars.com/api/?name=<?php echo urlencode($profiles[0]['full_name']); ?>&background=0D8ABC&color=fff&size=512';">
                </div>
                <div>
                    <div class="mini-label">Featured Profile</div>
                    <h3><?php echo htmlspecialchars($profiles[0]['full_name']); ?></h3>
                </div>
            </div>

            <div class="mini-label">Specialty</div>
            <p><?php echo htmlspecialchars($profiles[0]['title']); ?></p>

            <div class="tag-list">
                <span class="tag">HTML</span>
                <span class="tag">Nextjs</span>
                <span class="tag">JavaScript</span>
                <span class="tag">Figma</span>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section-header">
            <span class="eyebrow" style="color: var(--primary);">Profiles</span>
            <h2 class="section-title">Meet the team</h2>
        </div>

        <div class="profile-grid">
            <?php foreach ($profiles as $profile): ?>
                <article class="profile-card">
                    <div class="photo-wrap">
                        <img src="<?php echo htmlspecialchars($profile['photo']); ?>" alt="<?php echo htmlspecialchars($profile['full_name']); ?>" onerror="this.onerror=null;this.src='https://ui-avatars.com/api/?name=<?php echo urlencode($profile['full_name']); ?>&background=0D8ABC&color=fff&size=512';">
                    </div>
                    <h3><?php echo htmlspecialchars($profile['full_name']); ?></h3>
                    <div class="role"><?php echo htmlspecialchars($profile['title']); ?></div>
                    <p><?php echo htmlspecialchars(substr($profile['about_text'], 0, 120)); ?>...</p>

                    <div class="skills">
                        <?php
                        $skills = explode(',', $profile['skills']);
                        foreach (array_slice($skills, 0, 4) as $skill):
                            ?><span class="tag"><?php echo htmlspecialchars(trim($skill)); ?></span><?php
                        endforeach;
                        ?>
                    </div>

                    <div class="card-footer" style="margin-top: 22px;">
                        <a class="link-button" href="profile.php?id=<?php echo (int) $profile['id']; ?>">View Profile</a>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="section" style="background: #eef4fb;">
    <div class="container">
        <div class="section-header">
            <span class="eyebrow" style="color: var(--primary);">Portfolio</span>
            <h2 class="section-title">Our Projects</h2>
            <p>Click View Project to open each live deployment.</p>
        </div>

        <div class="projects-grid">
            <?php if (empty($projects)): ?>
                <p style="grid-column: 1 / -1; text-align: center; color: var(--muted);">No projects yet — check back soon.</p>
            <?php endif; ?>
            <?php foreach ($projects as $project): ?>
                <article class="project-card">
                    <div class="project-image">
                        <img src="<?php echo htmlspecialchars($project['image']); ?>" alt="<?php echo htmlspecialchars($project['title']); ?>">
                    </div>
                    <div class="content">
                        <?php if (!empty($project['author_name'])): ?>
                            <div class="meta"><?php echo htmlspecialchars($project['author_name']); ?></div>
                        <?php endif; ?>
                        <h3><?php echo htmlspecialchars($project['title']); ?></h3>
                        <p><?php echo htmlspecialchars($project['description']); ?></p>
                        <div class="tech">
                            <?php foreach (explode(',', $project['technologies']) as $technology): ?>
                                <span><?php echo htmlspecialchars(trim($technology)); ?></span>
                            <?php endforeach; ?>
                        </div>
                        <div class="card-footer">
                            <a class="link-button" href="<?php echo htmlspecialchars($project['project_url'] ?: '#'); ?>" target="_blank" rel="noreferrer">View Project</a>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>


<?php include __DIR__ . '/../partials/footer.php'; ?>
