<?php
require __DIR__ . '/database.php';

try {
    $pdo = connectDatabase();
    $projects = getProjects($pdo);
} catch (Throwable $e) {
    $projects = [
        [
            'title' => 'Prelim Exam - Pokemon App',
            'image' => 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/25.png',
            'description' => 'Prelim exam project by Mc Jovic Duarte - a Pokemon explorer app deployed on Vercel.',
            'technologies' => 'Next.js, JavaScript, CSS, Vercel, PokeAPI',
            'project_url' => 'https://prelim-exam-pokemon.vercel.app/',
            'author_name' => 'Mc Jovic L. Duarte',
        ],
        [
            'title' => 'Happy Toes App',
            'image' => 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=1200&q=80',
            'description' => 'Happy Toes project by Mc Jovic Duarte - a web application deployed on Vercel.',
            'technologies' => 'HTML, CSS, JavaScript, Vercel',
            'project_url' => 'https://happytoes.vercel.app/',
            'author_name' => 'Mc Jovic L. Duarte',
        ],
        [
            'title' => 'WS101 Exam App',
            'image' => 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&w=1200&q=80',
            'description' => 'WS101 exam project by Jhon Lloyd Soco - a web application deployed on Vercel.',
            'technologies' => 'HTML, CSS, JavaScript, Vercel',
            'project_url' => 'https://ws101-exam.vercel.app/',
            'author_name' => 'Jhon Lloyd J. Soco',
        ],
        [
            'title' => 'IT Prof EL1 App',
            'image' => 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80',
            'description' => 'IT Professional Elective 1 project by Jhon Lloyd Soco - a web application deployed on Vercel.',
            'technologies' => 'HTML, CSS, JavaScript, Vercel',
            'project_url' => 'https://it-prof-el-1.vercel.app/',
            'author_name' => 'Jhon Lloyd J. Soco',
        ],
    ];
}

$pageTitle = 'Projects | Blog Post';
include __DIR__ . '/../partials/header.php';
?>

<section class="section">
    <div class="container">
        <div class="section-header">
            <span class="eyebrow" style="color: var(--primary);">Portfolio</span>
            <h1 class="section-title">Projects</h1>
            <p>Explore our projects and click View Project to open each live deployment.</p>
        </div>

        <div class="projects-grid">
            <?php if (empty($projects)): ?>
                <p style="grid-column: 1 / -1; text-align: center; color: var(--muted);">No projects yet — check back soon.</p>
            <?php endif; ?>
            <?php foreach ($projects as $project): ?>
                <article class="project-card">
                    <div class="project-image">
                        <img src="<?php echo htmlspecialchars($project['image']); ?>" alt="<?php echo htmlspecialchars($project['title']); ?>">
                    </div>
                    <div class="content">
                        <?php if (!empty($project['author_name'])): ?>
                            <div class="meta"><?php echo htmlspecialchars($project['author_name']); ?></div>
                        <?php endif; ?>
                        <h3><?php echo htmlspecialchars($project['title']); ?></h3>
                        <p><?php echo htmlspecialchars($project['description']); ?></p>
                        <div class="tech">
                            <?php foreach (explode(',', $project['technologies']) as $technology): ?>
                                <span><?php echo htmlspecialchars(trim($technology)); ?></span>
                            <?php endforeach; ?>
                        </div>
                        <div class="card-footer">
                            <a class="link-button" href="<?php echo htmlspecialchars($project['project_url'] ?: '#'); ?>" target="_blank" rel="noreferrer">View Project</a>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php include __DIR__ . '/../partials/footer.php'; ?>
