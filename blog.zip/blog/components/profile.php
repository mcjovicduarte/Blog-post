<?php
require __DIR__ . '/database.php';

$id = isset($_GET['id']) ? (int) $_GET['id'] : 1;

try {
    $pdo = connectDatabase();
    $profile = getProfileById($pdo, $id);
    if (! $profile) {
        $profile = getProfileById($pdo, 1);
    }
    $projects = getProjectsByProfileId($pdo, (int) $profile['id']);
} catch (Throwable $e) {
    $profiles = fallbackProfiles();
    $profile = $profiles[0];
    if ($id === 2) {
        $profile = $profiles[1];
    }
    $projects = [];
    if ((int) $profile['id'] === 1) {
        $projects[] = [
            'title' => 'Prelim Exam - Pokemon App',
            'image' => 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/25.png',
            'description' => 'Prelim exam project by Mc Jovic Duarte - a Pokemon explorer app deployed on Vercel.',
            'technologies' => 'Next.js, JavaScript, CSS, Vercel, PokeAPI',
            'project_url' => 'https://prelim-exam-pokemon.vercel.app/',
        ];
        $projects[] = [
            'title' => 'Happy Toes App',
            'image' => 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=1200&q=80',
            'description' => 'Happy Toes project by Mc Jovic Duarte - a web application deployed on Vercel.',
            'technologies' => 'HTML, CSS, JavaScript, Vercel',
            'project_url' => 'https://happytoes.vercel.app/',
        ];
    }
    if ((int) $profile['id'] === 2) {
        $projects[] = [
            'title' => 'WS101 Exam App',
            'image' => 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&w=1200&q=80',
            'description' => 'WS101 exam project by Jhon Lloyd Soco - a web application deployed on Vercel.',
            'technologies' => 'HTML, CSS, JavaScript, Vercel',
            'project_url' => 'https://ws101-exam.vercel.app/',
        ];
        $projects[] = [
            'title' => 'IT Prof EL1 App',
            'image' => 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80',
            'description' => 'IT Professional Elective 1 project by Jhon Lloyd Soco - a web application deployed on Vercel.',
            'technologies' => 'HTML, CSS, JavaScript, Vercel',
            'project_url' => 'https://it-prof-el-1.vercel.app/',
        ];
    }
}

$pageTitle = htmlspecialchars($profile['full_name']) . ' | Profile';
include __DIR__ . '/../partials/header.php';
?>

<section class="single-profile">
    <div class="container profile-layout">
        <aside class="profile-main">
            <div class="photo-wrap">
                <img src="<?php echo htmlspecialchars($profile['photo']); ?>" alt="<?php echo htmlspecialchars($profile['full_name']); ?>" onerror="this.onerror=null;this.src='https://ui-avatars.com/api/?name=<?php echo urlencode($profile['full_name']); ?>&background=0D8ABC&color=fff&size=512';">
            </div>
            <h2><?php echo htmlspecialchars($profile['full_name']); ?></h2>
            <div class="role"><?php echo htmlspecialchars($profile['title']); ?></div>
            <p><?php echo htmlspecialchars($profile['about_text']); ?></p>

            <div class="socials">
                <a class="social-link" href="mailto:<?php echo htmlspecialchars($profile['email']); ?>">Email</a>
            
                <a class="social-link" href="<?php echo htmlspecialchars($profile['github'] ?? 'https://github.com'); ?>" target="_blank" rel="noreferrer">GitHub</a>
                <a class="social-link" href="<?php echo htmlspecialchars($profile['facebook'] ?? 'https://www.facebook.com'); ?>" target="_blank" rel="noreferrer">Facebook</a>
            </div>
        </aside>
        

        <div>
            <div class="info-panel">
                <h3>About Me</h3>
                <p><?php echo nl2br(htmlspecialchars($profile['about_text'])); ?></p>
            </div>

            <div class="content-box">
                <h3>Skills</h3>
                <ul class="skill-list">
                    <?php foreach (explode(',', $profile['skills']) as $skill): ?>
                        <li><?php echo htmlspecialchars(trim($skill)); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div class="content-box">
                <h3>Contact Information</h3>
                <ul class="contact-list">
                    <li>Email: <?php echo htmlspecialchars($profile['email']); ?></li>
                    <li>Phone: <?php echo htmlspecialchars($profile['phone']); ?></li>
                    <li>Location: <?php echo htmlspecialchars($profile['location']); ?></li>
                </ul>
            </div>
        </div>
    </div>
</section>

<section class="section" style="background: #eef4fb;">
    <div class="container">
        <div class="section-header">
            <span class="eyebrow" style="color: var(--primary);">Portfolio</span>
            <h2 class="section-title">Featured projects</h2>
        </div>

        <div class="projects-grid">
            <?php if (empty($projects)): ?>
                <p style="grid-column: 1 / -1; text-align: center; color: var(--muted);">No projects yet — check back soon.</p>
            <?php endif; ?>
            <?php foreach ($projects as $project): ?>
                <article class="project-card">
                    <div class="project-image">
                        <img src="<?php echo htmlspecialchars($project['image']); ?>" alt="<?php echo htmlspecialchars($project['title']); ?>">
                    </div>
                    <div class="content">
                        <h3><?php echo htmlspecialchars($project['title']); ?></h3>
                        <p><?php echo htmlspecialchars($project['description']); ?></p>
                        <div class="tech">
                            <?php foreach (explode(',', $project['technologies']) as $technology): ?>
                                <span><?php echo htmlspecialchars(trim($technology)); ?></span>
                            <?php endforeach; ?>
                        </div>
                        <div class="card-footer">
                            <a class="link-button" href="<?php echo htmlspecialchars($project['project_url'] ?: '#'); ?>" target="_blank" rel="noreferrer">View Project</a>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php include __DIR__ . '/../partials/footer.php'; ?>
