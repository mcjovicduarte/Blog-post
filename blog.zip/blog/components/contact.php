<?php
$pageTitle = 'Contact | BLog Post';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $message = 'Your message has been sent successfully. We will get back to you soon.';
}

include __DIR__ . '/../partials/header.php';
?>

<section class="section">
    <div class="container contact-grid">
        <div class="contact-card">
            <h3>Get in touch</h3>
            <p>We would love to talk about your next project, idea, or collaboration opportunity.</p>
            <ul class="contact-list">
                <li>Email: mcjovicduarte.202300566@gmail.com</li>
                <li>Phone: 09692094727</li>
                <li>Location: Iligan City,Lanao Del Norte</li>
            </ul>
        </div>

        <div class="contact-form">
            <?php if ($message !== '') { ?>
                <div class="form-success"><?php echo htmlspecialchars($message); ?></div>
            <?php } ?>

            <form method="post" action="contact.php">
                <div class="form-row">
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input id="name" name="name" type="text" placeholder="Your full name" required>
                    </div>

                    <div class="form-group">
                        <label for="email">Email</label>
                        <input id="email" name="email" type="email" placeholder="your@email.com" required>
                    </div>
                </div>

                <div class="form-group">
                    <label for="subject">Subject</label>
                    <input id="subject" name="subject" type="text" placeholder="Project inquiry" required>
                </div>

                <div class="form-group" style="margin-top: 18px;">
                    <label for="message">Message</label>
                    <textarea
                        id="message"
                        name="message"
                        placeholder="Tell us about your project..."
                        required
                    ></textarea>
                </div>

                <div style="margin-top: 22px;">
                    <button class="btn btn-primary" type="submit">Send Message</button>
                </div>
            </form>
        </div>
    </div>
</section>

<?php include __DIR__ . '/../partials/footer.php'; ?>
