    </main>

    <footer class="site-footer">
        <div class="container footer-grid">
            <div>
                <a href="index.php" class="brand footer-brand">
                    <span class="brand-mark">B</span>
                    <span>Blog Post</span>
                </a>
                <p>Modern portfolio and blog experiences built for ambitious people and growing ideas.</p>
            </div>

            <div>
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="projects.php">Projects</a></li>
                    <li><a href="contact.php">Contact</a></li>
                </ul>
            </div>

            <div>
                <h4>Profiles</h4>
                <ul>
                    <li><a href="profile.php?id=1">Mc Jovic Duarte</a></li>
                    <li><a href="profile.php?id=2">Jhon Lloyd Soco</a></li>
                </ul>
            </div>

            <div>
                <h4>Contact</h4>
                <ul>
                    <li><a href="https://www.facebook.com/mcjovic.lemosneroduarte">Facebook</a></li>
                    <li><a href="09692094727">09692094727</a></li>
                    <li><i>Iligan City, Lanao Del Norte</i></li>
                </ul>
            </div>
        </div>

        <div class="footer-bottom">
            <div class="container">
                <p>© <span id="year"></span> BLog Post. All rights reserved.</p>
            </div>
        </div>
    </footer>
</body>
</html>
