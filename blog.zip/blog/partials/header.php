<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle ?? 'BluePeak Studio'); ?></title>
    <meta name="description" content="Portfolio and blog website for two creative professionals.">
    <base href="/blog/">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <script defer src="script.js"></script>
</head>
<body>
    <header class="site-header">
        <div class="container nav-wrapper">
            <a href="index.php" class="brand" aria-label="Blog Post home">
                <span class="brand-mark">B</span>
                <span>Blog Post</span>
            </a>

            <button class="nav-toggle" aria-label="Open menu" aria-expanded="false">
                <span></span>
                <span></span>
                <span></span>
            </button>

            <nav class="main-nav" aria-label="Main navigation">
                <a href="index.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'index.php' ? 'active' : ''; ?>">Home</a>
                <a href="profile.php?id=1" class="<?php echo basename($_SERVER['PHP_SELF']) === 'profile.php' && ($_GET['id'] ?? 1) == 1 ? 'active' : ''; ?>">Mc Jovic Duarte</a>
                <a href="profile.php?id=2" class="<?php echo basename($_SERVER['PHP_SELF']) === 'profile.php' && ($_GET['id'] ?? 1) == 2 ? 'active' : ''; ?>">Jhon Lloyd Soco</a>
                <a href="contact.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'contact.php' ? 'active' : ''; ?>">Contact</a>
            </nav>
        </div>
    </header>

    <main class="page-content">
