<?php
require __DIR__ . '/components/profile.php';
