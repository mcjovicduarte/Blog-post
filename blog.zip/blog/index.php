<?php
require __DIR__ . '/components/index.php';
